java -jar kona.bin $1 $2
